<?php 

namespace App\Filtre;

class Search 
{
    /*
    * @var string
    */
    public $string = '';

    /*
    * @var category[]
    */
    public $categories = [];

    /*
    * @var structure[]
    */
    public $structures = [];

    /*
    * @var open
    */

    public $open = true;

}


?>